﻿namespace GrapheneTraceApp1
{
    partial class AdminDashboardForm
    {
        private System.Windows.Forms.Button btnUploadCSV;
        private System.Windows.Forms.Button btnViewData;
        private System.Windows.Forms.DataGridView dataGridView;

        private void InitializeComponent()
        {
            this.btnUploadCSV = new System.Windows.Forms.Button();
            this.btnViewData = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();

            // 
            // btnUploadCSV
            // 
            this.btnUploadCSV.Location = new System.Drawing.Point(150, 100);
            this.btnUploadCSV.Name = "btnUploadCSV";
            this.btnUploadCSV.Size = new System.Drawing.Size(150, 30);
            this.btnUploadCSV.Text = "Upload CSV";
            this.btnUploadCSV.Click += new System.EventHandler(this.BtnUploadCSV_Click);

            // 
            // btnViewData
            // 
            this.btnViewData.Location = new System.Drawing.Point(150, 150);
            this.btnViewData.Name = "btnViewData";
            this.btnViewData.Size = new System.Drawing.Size(150, 30);
            this.btnViewData.Text = "View Data";
            this.btnViewData.Click += new System.EventHandler(this.BtnViewData_Click);

            // 
            // dataGridView
            // 
            this.dataGridView.Location = new System.Drawing.Point(50, 200);
            this.dataGridView.Size = new System.Drawing.Size(700, 300);
            this.dataGridView.Visible = false; // Hide the DataGridView until data is uploaded

            // 
            // AdminDashboardForm
            // 
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.btnUploadCSV);
            this.Controls.Add(this.btnViewData);
            this.Controls.Add(this.dataGridView);
            this.Name = "AdminDashboardForm";
            this.Text = "Admin Dashboard";
        }
    }
}
