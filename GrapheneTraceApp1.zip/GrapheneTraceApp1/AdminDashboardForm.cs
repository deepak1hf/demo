﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace GrapheneTraceApp1
{
    public partial class AdminDashboardForm : Form
    {
        public AdminDashboardForm()
        {
            InitializeComponent(); // Initializes the form and components
            BuildAdminDashboardUI(); // Setup UI elements (buttons, labels, etc.)
        }

        private void BuildAdminDashboardUI()
        {
            // Set up the form's title and dimensions
            this.Text = "Admin Dashboard";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Create a label for the title
            Label lblTitle = new Label();
            lblTitle.Text = "Admin Dashboard";
            lblTitle.Font = new Font("Arial", 20, FontStyle.Bold);
            lblTitle.Location = new Point(300, 50);
            lblTitle.AutoSize = true;
            this.Controls.Add(lblTitle);

            // **Do NOT add buttons here again!**
            // These buttons are already created in the Designer.cs file.
        }

        // Handle "Upload CSV" button click
        private void BtnUploadCSV_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*";
            openFileDialog.Title = "Select a CSV File";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                LoadCSVData(filePath); // Load the data from the uploaded CSV
            }
        }

        // Load CSV data into DataGridView
        private void LoadCSVData(string filePath)
        {
            try
            {
                DataTable dt = new DataTable();

                // Read CSV file
                string[] csvData = File.ReadAllLines(filePath);

                // Ensure there are 32 columns in the first row
                string[] columns = csvData[0].Split(',');
                for (int i = 0; i < 32; i++)
                {
                    dt.Columns.Add($"Column {i + 1}");  // Create columns dynamically
                }

                // Add rows to DataTable for each CSV row
                foreach (var row in csvData)
                {
                    string[] values = row.Split(',');

                    // Ensure 32 values per row
                    if (values.Length == 32)
                    {
                        dt.Rows.Add(values);
                    }
                }

                // Display data in DataGridView
                dataGridView.DataSource = dt;
                dataGridView.Visible = true; // Show DataGridView after data is loaded
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading CSV file: " + ex.Message);
            }
        }

        // Handle "View Data" button click
        private void BtnViewData_Click(object sender, EventArgs e)
        {
            // Show the DataGridView
            dataGridView.Visible = true;
        }
    }
}
