﻿namespace GrapheneTraceApp1
{
    partial class ClinicianDashboardForm
    {
        private System.Windows.Forms.Button btnViewPatientData;
        private System.Windows.Forms.Button btnCheckAlerts;
        private System.Windows.Forms.DataGridView dataGridView;

        private void InitializeComponent()
        {
            this.btnViewPatientData = new System.Windows.Forms.Button();
            this.btnCheckAlerts = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();

            // 
            // btnViewPatientData
            // 
            this.btnViewPatientData.Location = new System.Drawing.Point(150, 100);
            this.btnViewPatientData.Name = "btnViewPatientData";
            this.btnViewPatientData.Size = new System.Drawing.Size(150, 30);
            this.btnViewPatientData.Text = "View Patient Data";
            this.btnViewPatientData.Click += new System.EventHandler(this.BtnViewPatientData_Click);

            // 
            // btnCheckAlerts
            // 
            this.btnCheckAlerts.Location = new System.Drawing.Point(150, 150);
            this.btnCheckAlerts.Name = "btnCheckAlerts";
            this.btnCheckAlerts.Size = new System.Drawing.Size(150, 30);
            this.btnCheckAlerts.Text = "Check Alerts";
            this.btnCheckAlerts.Click += new System.EventHandler(this.BtnCheckAlerts_Click);

            // 
            // dataGridView
            // 
            this.dataGridView.Location = new System.Drawing.Point(50, 200);
            this.dataGridView.Size = new System.Drawing.Size(700, 300);
            this.dataGridView.Visible = false; // Hide the DataGridView until data is uploaded

            // 
            // ClinicianDashboardForm
            // 
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.btnViewPatientData);
            this.Controls.Add(this.btnCheckAlerts);
            this.Controls.Add(this.dataGridView);
            this.Name = "ClinicianDashboardForm";
            this.Text = "Clinician Dashboard";
        }
    }
}
