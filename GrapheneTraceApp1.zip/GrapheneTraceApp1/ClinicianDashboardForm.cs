﻿using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace GrapheneTraceApp1
{
    public partial class ClinicianDashboardForm : Form
    {
        public ClinicianDashboardForm()
        {
            InitializeComponent(); // Initializes the form and components.
        }

        // Handle "View Patient Data" button click
        private void BtnViewPatientData_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*";
            openFileDialog.Title = "Select a CSV File for Patient Data";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                LoadPatientData(filePath); // Load the data from the uploaded CSV
            }
        }

        // Load patient data into DataGridView
        private void LoadPatientData(string filePath)
        {
            try
            {
                DataTable dt = new DataTable();

                // Read CSV file
                string[] csvData = File.ReadAllLines(filePath);

                if (csvData.Length > 0)
                {
                    // Use the first row for column names (assuming the first row is for headers)
                    string[] columns = csvData[0].Split(',');

                    // Remove any empty columns and columns with only the value '0'
                    columns = columns.Where(c => !string.IsNullOrWhiteSpace(c) && c != "0").ToArray(); // Removing empty and '0' columns

                    // Create columns in the DataTable dynamically based on the CSV header
                    foreach (var column in columns)
                    {
                        dt.Columns.Add(column.Trim());  // Trim to remove any leading/trailing spaces
                    }

                    // Add rows to DataTable for each CSV row (skip the header row)
                    foreach (var row in csvData.Skip(1)) // Skip the first row since it's the header
                    {
                        string[] values = row.Split(',');

                        // Ensure the number of values in each row matches the column count
                        if (values.Length == dt.Columns.Count)
                        {
                            // Skip rows where any value is empty
                            if (values.All(value => !string.IsNullOrWhiteSpace(value)))
                            {
                                dt.Rows.Add(values);
                            }
                        }
                    }

                    // Display data in DataGridView
                    dataGridView.DataSource = dt;
                    dataGridView.Visible = true;
                }
                else
                {
                    MessageBox.Show("The CSV file is empty.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading CSV file: " + ex.Message);
            }
        }

        // Handle "Check Alerts" button click
        private void BtnCheckAlerts_Click(object sender, EventArgs e)
        {
            MessageBox.Show("No new alerts for patients at this time.");
        }
    }
}
