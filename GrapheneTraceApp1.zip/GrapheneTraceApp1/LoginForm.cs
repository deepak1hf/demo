﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace GrapheneTraceApp1
{
    public partial class LoginForm : Form
    {
        private List<User> users = new List<User>();

        public LoginForm()
        {
            InitializeComponent();
            LoadUserData();
        }

        // Load user data from JSON
        private void LoadUserData()
        {
            // Use the startup path to get the file location
            string filePath = Path.Combine(Application.StartupPath, "users.json");

            if (File.Exists(filePath))
            {
                string jsonData = File.ReadAllText(filePath);
                users = JsonConvert.DeserializeObject<List<User>>(jsonData);
            }
            else
            {
                MessageBox.Show("User data file is missing.");
            }
        }


        // Login button click
        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            var user = users.FirstOrDefault(u => u.Username == username && u.Password == password);

            if (user != null)
            {
                if (user.Role == "Admin")
                {
                    AdminDashboardForm adminDashboard = new AdminDashboardForm();
                    adminDashboard.Show();
                    this.Hide();
                }
                else if (user.Role == "Clinician")
                {
                    ClinicianDashboardForm clinicianDashboard = new ClinicianDashboardForm();
                    clinicianDashboard.Show();
                    this.Hide();
                }
                else if (user.Role == "Patient")
                {
                    PatientDashboardForm patientDashboard = new PatientDashboardForm();
                    patientDashboard.Show();
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show("Invalid username or password.");
            }
        }

        // User class to represent a user
        public class User
        {
            public string Username { get; set; }
            public string Password { get; set; }
            public string Role { get; set; }
        }
    }
}
