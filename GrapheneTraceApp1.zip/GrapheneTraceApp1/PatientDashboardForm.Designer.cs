﻿using System.Drawing;

namespace GrapheneTraceApp1
{
    partial class PatientDashboardForm
    {
        private System.Windows.Forms.Button btnViewMyData;
        private System.Windows.Forms.Button btnSubmitFeedback;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.TextBox feedbackTextBox;
        private System.Windows.Forms.Label lblFeedback;

        private void InitializeComponent()
        {
            this.btnViewMyData = new System.Windows.Forms.Button();
            this.btnSubmitFeedback = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.feedbackTextBox = new System.Windows.Forms.TextBox();
            this.lblFeedback = new System.Windows.Forms.Label();

            // 
            // btnViewMyData
            // 
            this.btnViewMyData.Location = new System.Drawing.Point(150, 100);
            this.btnViewMyData.Name = "btnViewMyData";
            this.btnViewMyData.Size = new System.Drawing.Size(150, 30);
            this.btnViewMyData.Text = "View My Data";
            this.btnViewMyData.Click += new System.EventHandler(this.BtnViewMyData_Click);

            // 
            // btnSubmitFeedback
            // 
            this.btnSubmitFeedback.Location = new System.Drawing.Point(150, 150);
            this.btnSubmitFeedback.Name = "btnSubmitFeedback";
            this.btnSubmitFeedback.Size = new System.Drawing.Size(150, 30);
            this.btnSubmitFeedback.Text = "Submit Feedback";
            this.btnSubmitFeedback.Click += new System.EventHandler(this.BtnSubmitFeedback_Click);

            // 
            // dataGridView
            // 
            this.dataGridView.Location = new System.Drawing.Point(50, 200);
            this.dataGridView.Size = new System.Drawing.Size(700, 300);
            this.dataGridView.Visible = false; // Hide DataGridView until data is uploaded

            // 
            // feedbackTextBox
            // 
            this.feedbackTextBox.Location = new System.Drawing.Point(50, 550);
            this.feedbackTextBox.Size = new System.Drawing.Size(700, 100);
            this.feedbackTextBox.Multiline = true;
            this.feedbackTextBox.BackColor = Color.LightYellow;

            // 
            // lblFeedback
            // 
            this.lblFeedback.Text = "Your Feedback";
            this.lblFeedback.Font = new Font("Arial", 12, FontStyle.Bold);
            this.lblFeedback.Location = new Point(50, 520);

            // 
            // PatientDashboardForm
            // 
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.btnViewMyData);
            this.Controls.Add(this.btnSubmitFeedback);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.feedbackTextBox);
            this.Controls.Add(this.lblFeedback);
            this.Name = "PatientDashboardForm";
            this.Text = "Patient Dashboard";
        }
    }
}
