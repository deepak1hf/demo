﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace GrapheneTraceApp1
{
    public partial class PatientDashboardForm : Form
    {
        public PatientDashboardForm()
        {
            InitializeComponent(); // Initializes the form and components
        }

        // Handle "View My Data" button click
        private void BtnViewMyData_Click(object sender, EventArgs e)
        {
            // Logic to view patient data (for example, loading a CSV or data file)
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*";
            openFileDialog.Title = "Select a CSV File for Patient Data";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                LoadPatientData(filePath); // Load the data from the uploaded CSV
            }
        }

        // Load patient data into DataGridView
        private void LoadPatientData(string filePath)
        {
            try
            {
                DataTable dt = new DataTable();

                // Read CSV file
                string[] csvData = File.ReadAllLines(filePath);

                if (csvData.Length > 0)
                {
                    // Use the first row for column names (assuming the first row is for headers)
                    string[] columns = csvData[0].Split(',');

                    // Create columns in the DataTable dynamically based on the CSV header
                    foreach (var column in columns)
                    {
                        if (!string.IsNullOrWhiteSpace(column) && !dt.Columns.Contains(column)) // Avoid empty or duplicate columns
                        {
                            dt.Columns.Add(column.Trim());  // Trim to remove any leading/trailing spaces
                        }
                    }

                    // Add rows to DataTable for each CSV row (skip the header row)
                    foreach (var row in csvData.Skip(1)) // Skip the first row since it's the header
                    {
                        string[] values = row.Split(',');

                        // Ensure the number of values in each row matches the column count
                        if (values.Length == dt.Columns.Count)
                        {
                            // Skip rows where any value is empty
                            if (values.All(value => !string.IsNullOrWhiteSpace(value)))
                            {
                                dt.Rows.Add(values);
                            }
                        }
                    }

                    // Display data in DataGridView
                    dataGridView.DataSource = dt;
                    dataGridView.Visible = true;
                }
                else
                {
                    MessageBox.Show("The CSV file is empty.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading CSV file: " + ex.Message);
            }
        }

        // Handle the "Submit Feedback" button click
        private void BtnSubmitFeedback_Click(object sender, EventArgs e)
        {
            string feedback = feedbackTextBox.Text;

            if (!string.IsNullOrWhiteSpace(feedback))
            {
                // Logic to submit the feedback (e.g., saving it to a file or database)
                MessageBox.Show("Thank you for your feedback.");
                feedbackTextBox.Clear(); // Clear the feedback text box after submission
            }
            else
            {
                MessageBox.Show("Please enter some feedback before submitting.");
            }
        }
    }
}
