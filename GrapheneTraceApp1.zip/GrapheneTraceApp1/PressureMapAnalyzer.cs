﻿namespace GrapheneTraceApp1
{
    public static class PressureMapAnalyzer
    {
        private const int Threshold = 100;  // Define the pressure threshold for high-pressure areas

        // Method to analyze the 32x32 pressure matrix
        public static bool[,] AnalyzePressureMap(int[,] pressureMatrix)
        {
            bool[,] highPressureRegions = new bool[32, 32];  // To store results of high-pressure detection

            // Loop through the pressure matrix
            for (int i = 0; i < 32; i++)
            {
                for (int j = 0; j < 32; j++)
                {
                    // If the pressure exceeds the threshold, mark it as high pressure
                    highPressureRegions[i, j] = pressureMatrix[i, j] >= Threshold;
                }
            }

            return highPressureRegions;
        }
    }
}
